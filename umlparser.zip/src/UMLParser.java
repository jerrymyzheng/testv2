

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import net.sourceforge.plantuml.SourceStringReader;

/**
 * UMLParser uml解析器
 * 利用CodeParser将一个文件夹中的所有源码信息提取出来，然后再转化成plantuml的输入格式，利用plantuml画出类图
 *
 */
public class UMLParser {

	/** 输入文件夹，内部含有待解析成uml图的所有.java文件 */
	private File inputFile = null;

	/** 输入文件的字符编码格式 */
	private String encode = null;

	/** 通过调用CodeParser获得的所有类信息 */
	private List<ClassSchema> classInfoList = null;

	/** 通过调用CodeParser获得的所有接口信息 */
	private List<InterfaceSchema> interfaceInfoList = null;

	/** 将classInfoList和interfaceInfoList转化成plantuml的输入 */
	private String intermediateCode = null;

	/** 构造方法（含有字符编码） */
	public UMLParser(File inputFile, String encode) {
		super();
		this.inputFile = inputFile;
		this.encode = encode;
		init();
	}

	/** 构造方法（不含有字符编码，采取默认的utf-8） */
	public UMLParser(File inputFile) {
		super();
		this.inputFile = inputFile;
		this.encode = "utf-8";
		init();
	}

	/** 调用CodeParser获得的所有类信息和接口信息 */
	private void init() {
		CodeParser codeParser = new CodeParser();
		codeParser.handle(inputFile, encode);
		classInfoList = codeParser.getClassInfoList();
		interfaceInfoList = codeParser.getInterfaceInfoList();
	}

	/**
	 * 根据获得到的类信息和接口信息，将其转化成plantuml的输入
	 */
	private void geneIntermediateCode() {
		StringBuilder sb = new StringBuilder("@startuml\n");
		sb.append("skinparam classAttributeIconSize 0\n");
		//记录uses的相关信息，key uses value。采用hashmap是为了让相同的uses关系仅出现一次
		HashMap<String, String> useRelationShips = new HashMap<String, String>();

		//对所有接口信息进行处理
		for(InterfaceSchema item : interfaceInfoList) {
			//声明这是一个接口
			sb.append("interface " + item.getInterfaceName() + "\n");
			//遍历该接口的所有方法
			List<FunctionSchema> functionList = item.getFunctionList();
			for(FunctionSchema function : functionList) {
				//仅显示public的function
				if(function.getAccessAuthority() == 4) {
					String param = "";//组合所有的参数信息
					for(int i = 0; i < function.getParameterList().size(); i++) {
						param += (function.getParameterList().get(i).getParameterName() + " : " + 
								function.getParameterList().get(i).getParameterType());
						if(i != function.getParameterList().size() - 1) {
							param += ",";
						}
					}
					//使用html语法使得接口的方法信息显示为斜体
					sb.append(item.getInterfaceName() + " : <i>+ " + function.getFunctionName() + "(" + param + ") : " + function.getReturnType() + "</i>\n");
					//由于文档仅要求识别class到 interface的uses关系，所以这里就不需要识别接口的任何uses信息了
				}
			}
		}

		//声明类之间的继承关系（继承关系用实线）
		for(ClassSchema item : classInfoList) {
			List<String> extendsClassNames = item.getExtendsList();
			for(String name : extendsClassNames) {
				sb.append(name + " <|-- " + item.getClassName() + "\n");
			}
		}

		//声明类与接口之间的实现关系（实现关系用虚线）
		for(ClassSchema item : classInfoList) {
			List<String> impleInterfaceNames = item.getImplementsList();
			for(String name : impleInterfaceNames) {
				sb.append(name + " <|.. " + item.getClassName() + "\n");
			}
		}

		//对类的方法信息进行处理
		for(ClassSchema item : classInfoList) {
			List<FunctionSchema> functionList = item.getFunctionList();
			for(FunctionSchema function : functionList) {
				//仅显示public的function
				if(function.getAccessAuthority() == 4) {
					//对set和get方法进行处理
					List<AttributeSchema> attrInfo = item.getAttributeList();
					boolean flag = true;
					for(AttributeSchema attr : attrInfo) {
						if(("get" + attr.getAttributeName()).toLowerCase().equals(function.getFunctionName().toLowerCase()) || 
								("set" + attr.getAttributeName()).toLowerCase().equals(function.getFunctionName().toLowerCase())) {
							//对于含有set和get方法的属性，令其访问权限为public
							attr.setAccessAuthority((byte)4);
							flag = false;
							break;
						}
					}
					//仅显示非set和get方法
					if(flag) {
						String param = "";//组合所有的参数信息
						for(int i = 0; i < function.getParameterList().size(); i++) {
							param += (function.getParameterList().get(i).getParameterName() + " : " + 
									function.getParameterList().get(i).getParameterType());
							if(i != function.getParameterList().size() - 1) {
								param += ",";
							}
						}
						if(function.getReturnType() == null) {//构造方法
							sb.append(item.getClassName() + " : + " + function.getFunctionName() + "(" + param + ")\n");
						} else {//非构造方法
							sb.append(item.getClassName() + " : + " + function.getFunctionName() + "(" + param + ") : " + function.getReturnType() + "\n");
						}
					}
					//识别该类对所有接口的uses信息
					for(int i = 0; i < function.getParameterList().size(); i++) {
						for(int j = 0; j < interfaceInfoList.size(); j++) {
							if(function.getParameterList().get(i).getParameterType().contains(interfaceInfoList.get(j).getInterfaceName() + "[]") ||
									function.getParameterList().get(i).getParameterType().contains("<" + interfaceInfoList.get(j).getInterfaceName() + ">") ||
									function.getParameterList().get(i).getParameterType().equals(interfaceInfoList.get(j).getInterfaceName())){
								useRelationShips.put(item.getClassName(), interfaceInfoList.get(j).getInterfaceName());
							}
						}
					}
				}
			}
		}

		//对类的属性信息进行处理
		//relationShips记录的是类、接口之间的关联关系
		ArrayList<RelationShip> relationShips = new ArrayList<RelationShip>();
		for(ClassSchema item : classInfoList) {
			List<AttributeSchema> attrInfo = item.getAttributeList();
			for(AttributeSchema attr : attrInfo) {
				byte flag = 0;
				int m = 0, n = 0;
				//检查该属性的数据类型是否关联一个自定义的类
				for(; m < classInfoList.size(); m++) {
					if(attr.getDataType().contains(classInfoList.get(m).getClassName() + "[]")|| 
							attr.getDataType().contains("<" + classInfoList.get(m).getClassName() + ">")) {
						flag = 2;
						break;
					}
					if(attr.getDataType().equals((classInfoList.get(m).getClassName()))) {
						flag = 1;
						break;
					}
				}

				//检查该属性的数据类型是否关联一个自定义的接口
				for(; n < interfaceInfoList.size(); n++) {
					if(attr.getDataType().contains(interfaceInfoList.get(n).getInterfaceName() + "[]")|| 
							attr.getDataType().contains("<" + interfaceInfoList.get(n).getInterfaceName() + ">")) {
						flag = 4;
						break;
					}
					if(attr.getDataType().equals((interfaceInfoList.get(n).getInterfaceName()))) {
						flag = 3;
						break;
					}
				}
				//该属性不关联任何的自定义的类或者接口
				if(flag == 0) {
					if(attr.getAccessAuthority() == 1) {
						sb.append(item.getClassName() + " : - " + attr.getAttributeName() + " : " + 
								attr.getDataType() + "\n");
					} else if(attr.getAccessAuthority() == 4) {
						sb.append(item.getClassName() + " : + " + attr.getAttributeName() + " : " + 
								attr.getDataType() + "\n");
					}
				} else if(flag == 1) {//该属性关联一个自定义类，并且是1:1的关联关系
					for(int j = 0; j < relationShips.size(); j++) {
						if((relationShips.get(j).getName1().equals(item.getClassName()) && 
								relationShips.get(j).getName2().equals(classInfoList.get(m).getClassName())) || 
								(relationShips.get(j).getName2().equals(item.getClassName()) && 
										relationShips.get(j).getName1().equals(classInfoList.get(m).getClassName()))) {
							break;
						}
						if(j == relationShips.size() - 1) {
							relationShips.add(new RelationShip(item.getClassName(), classInfoList.get(m).getClassName(), "1", "1"));
							break;
						}
					}
					if(relationShips.size() == 0) {
						relationShips.add(new RelationShip(item.getClassName(), classInfoList.get(m).getClassName(), "1", "1"));
					}
				} else if(flag == 2) {//该属性关联一个自定义类，并且是1:many的关联关系
					for(int j = 0; j < relationShips.size(); j++) {
						if(relationShips.get(j).getName1().equals(item.getClassName()) && 
								relationShips.get(j).getName2().equals(classInfoList.get(m).getClassName())) { 
							relationShips.get(j).setNum2("many");
						}else if(relationShips.get(j).getName2().equals(item.getClassName()) && 
								relationShips.get(j).getName1().equals(classInfoList.get(m).getClassName())) {
							relationShips.get(j).setNum1("many");
						}
						if(j == relationShips.size() - 1) {
							relationShips.add(new RelationShip(item.getClassName(), classInfoList.get(m).getClassName(), "1", "many"));
							break;
						}
					}
					if(relationShips.size() == 0) {
						relationShips.add(new RelationShip(item.getClassName(), classInfoList.get(m).getClassName(), "1", "many"));
					}
				} else if(flag == 3) {//该属性关联一个自定义接口，并且是1:1的关联关系
					for(int j = 0; j < relationShips.size(); j++) {
						if((relationShips.get(j).getName1().equals(item.getClassName()) && 
								relationShips.get(j).getName2().equals(interfaceInfoList.get(n).getInterfaceName())) || 
								(relationShips.get(j).getName2().equals(item.getClassName()) && 
										relationShips.get(j).getName1().equals(interfaceInfoList.get(n).getInterfaceName()))) {
							break;
						}
						if(j == relationShips.size() - 1) {
							relationShips.add(new RelationShip(item.getClassName(), interfaceInfoList.get(n).getInterfaceName(), "1", "1"));
							break;
						}
					}
					if(relationShips.size() == 0) {
						relationShips.add(new RelationShip(item.getClassName(), interfaceInfoList.get(n).getInterfaceName(), "1", "1"));
					}
				} else if(flag == 4) {//该属性关联一个自定义接口，并且是1:many的关联关系
					for(int j = 0; j < relationShips.size(); j++) {
						if(relationShips.get(j).getName1().equals(item.getClassName()) && 
								relationShips.get(j).getName2().equals(interfaceInfoList.get(n).getInterfaceName())) { 
							relationShips.get(j).setNum2("many");
						}else if(relationShips.get(j).getName2().equals(item.getClassName()) && 
								relationShips.get(j).getName1().equals(interfaceInfoList.get(n).getInterfaceName())) {
							relationShips.get(j).setNum1("many");
						}
						if(j == relationShips.size() - 1) {
							relationShips.add(new RelationShip(item.getClassName(), interfaceInfoList.get(n).getInterfaceName(), "1", "many"));
							break;
						}
					}
					if(relationShips.size() == 0) {
						relationShips.add(new RelationShip(item.getClassName(), interfaceInfoList.get(n).getInterfaceName(), "1", "many"));
					}
				}
			}
		}

		//uses关系声明
		Iterator<Entry<String, String>> iter = useRelationShips.entrySet().iterator();
		while(iter.hasNext()) {
			Entry<String, String> item = iter.next();
			sb.append(item.getKey() + " ..> " + item.getValue() + " : uses\n");
		}

		//关联关系声明
		for(int i = 0; i < relationShips.size(); i++) {
			sb.append(relationShips.get(i).getName1() + " \"" + relationShips.get(i).getNum1() + "\" -- \"" +
					relationShips.get(i).getNum2() + "\" " + relationShips.get(i).getName2() + "\n");
		}
		sb.append("@enduml");
		intermediateCode = sb.toString();
	}
	
	/**
	 * 程序入口
	 * 注意，这里采用的是默认utf-8字符编码
	 * 
	 */
	public static void main(String[] args) throws IOException {
		//获取控制台输入
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String inputLine = null;
		String[] inputLineArr = null;
		System.out.println("**********************************************");
		System.out.println("**    UML Parser by mengyuan zheng          **");
		System.out.println("**********************************************");
		System.out.println("** How to use:                              **");
		System.out.println("** umlparser <classpath> <output file name> **");
		System.out.println("** q: exit                                  **");
		System.out.println("**********************************************");
		System.out.print("UML Parser>>");
		while((inputLine = br.readLine()) != null) {
			if(inputLine.equals("q")) {
				System.out.println("UML Parser>>Bye!");
				break;
			}
			inputLineArr = inputLine.split("[ \t]+"); 
			if(inputLineArr.length != 3 || !inputLineArr[0].equals("umlparser")) {
				System.out.println("UML Parser>>Format: umlparser <classpath> <output file name>");
			} else {
				UMLParser umlGenerator = new UMLParser(new File(inputLineArr[1]));
				umlGenerator.geneIntermediateCode();
				OutputStream outputFile = new FileOutputStream(inputLineArr[2]);
				//调用plantuml生成类图
				SourceStringReader reader = new SourceStringReader(umlGenerator.intermediateCode);
				reader.generateImage(outputFile);
				outputFile.close();
				System.out.println("UML Parser>>Success!");
			}
			System.out.print("UML Parser>>");
		}
		br.close();
	}
}

/**
 * RelationShip 类与接口之间的关联关系信息
 *
 */
class RelationShip {
	
	private String name1 = null;//类或接口名1
	private String name2 = null;//类或接口名2
	private String num1 = null;//1 or many
	private String num2 = null;//1 or many
	
	public RelationShip(String name1, String name2, String num1, String num2) {
		super();
		this.name1 = name1;
		this.name2 = name2;
		this.num1 = num1;
		this.num2 = num2;
	}

	public String getName1() {
		return name1;
	}

	public String getName2() {
		return name2;
	}

	public String getNum1() {
		return num1;
	}

	public void setNum1(String num1) {
		this.num1 = num1;
	}

	public String getNum2() {
		return num2;
	}

	public void setNum2(String num2) {
		this.num2 = num2;
	}
}
