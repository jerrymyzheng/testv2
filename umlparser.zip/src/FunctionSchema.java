

import java.util.List;

/**
 * FunctionSchema 方法信息结构
 * 用来存储方法的所有信息
 *
 */
public class FunctionSchema {

	/**
	 * 方法的访问权限
	 * 1:private; 2:default; 3:protected; 4:public
	 * */
	private byte accessAuthority;

	/** 该方法是否为静态方法，默认不是 */
	private boolean staticFlag = false;

	/** 方法的返回数据类型 */
	private String returnType = null;

	/** 方法名称 */
	private String functionName = null;

	/** 该方法的传入参数 */
	private List<Parameter> parameterList = null;

	/** 构造方法 */
	public FunctionSchema() {
		super();
	}

	/** 下面为所有属性的set和get方法 */
	public byte getAccessAuthority() {
		return accessAuthority;
	}

	public void setAccessAuthority(byte accessAuthority) {
		this.accessAuthority = accessAuthority;
	}

	public boolean isStaticFlag() {
		return staticFlag;
	}

	public void setStaticFlag(boolean staticFlag) {
		this.staticFlag = staticFlag;
	}

	public String getReturnType() {
		return returnType;
	}

	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public List<Parameter> getParameterList() {
		return parameterList;
	}

	public void setParameterList(List<Parameter> parameterList) {
		this.parameterList = parameterList;
	}
}
