

/**
 * AttributeSchema 属性信息结构
 * 用来存储类中属性的相关信息
 *
 */
public class AttributeSchema {

	/**
	 * 属性的访问权限
	 * 1:private; 2:default; 3:protected; 4:public
	 * */
	private byte accessAuthority;

	/** 属性的数据类型 */
	private String dataType = null;

	/** 属性名称 */
	private String attributeName = null;

	/** 构造方法 */
	public AttributeSchema() {
		super();
	}

	/** 下面为所有属性的set和get方法 */
	public byte getAccessAuthority() {
		return accessAuthority;
	}

	public void setAccessAuthority(byte accessAuthority) {
		this.accessAuthority = accessAuthority;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getAttributeName() {
		return attributeName;
	}

	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}
}
