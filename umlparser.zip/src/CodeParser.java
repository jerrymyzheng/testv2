

import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * CodeParser 源码解析器
 * 提取java源码中的类信息（+属性信息，+方法信息）和接口信息（+方法信息）
 *
 */
public class CodeParser {

	/** 识别类定义的正则表达式 */
	private String classRegex = "((private||protected||public)[ \\t]+)?" + //类的访问权限
	"class[ \\t]+" + //类定义关键字
	"[0-9A-Za-z$_]+[ \\t]*" + //类名称
	"(extends[ \\t]+[0-9A-Za-z$_]+[ \\t]*)?" + //类的继承信息
	"(implements[ \\t]+([0-9A-Za-z$_]+[ \\t]*,)*[ \\t]*[0-9A-Za-z$_]+[ \\t]*)?" + //类的实现信息
	"\\{";

	/** 识别接口定义的正则表达式 */
	private String interfaceRegex = "((private||protected||public)[ \\t]+)?" + //接口的访问权限
	"interface[ \\t]+" + //接口定义关键字
	"[0-9A-Za-z$_]+[ \\t]*" + //接口名称
	"\\{";

	/** 识别类中属性定义的正则表达式 */
	private String attributeRegex = "((private||protected||public)[ \\t]+)?" + //属性的访问权限
	"[0-9A-Za-z$_\\[\\]<>]+[ \\t]+" + //属性的数据类型
	"[0-9A-Za-z$_]+" + //属性名称
	"[ \t]*[=;]+";

	/** 识别类和接口中方法定义的正则表达式 */
	private String functionRegex = "((private||protected||public)[ \\t]+)?" + //方法的访问权限
	"(static[ \\t]+)?" + //静态方法标示关键字
	"(abstract[ \\t]+)?" + //抽象方法标示关键字
	"[0-9A-Za-z$_\\[\\]<>]+[ \\t]+" + //方法的返回数据类型
	"[0-9A-Za-z$_]+[ \\t]*" + //方法的名称
	"\\([ \\t]*" +
	"([0-9A-Za-z$_\\[\\]<>]+[ \\t]+[0-9A-Za-z$_]+[ \\t,]*)*" +//方法的传入参数信息
	"\\)";

	/** 分别对上述正则表达式进行编译 */
	private Pattern classPattern = Pattern.compile(classRegex);
	private Pattern interfacePattern = Pattern.compile(interfaceRegex);
	private Pattern attributePattern = Pattern.compile(attributeRegex);
	private Pattern functionPattern = Pattern.compile(functionRegex);

	/** 通过解析获得的所有类信息 */
	private List<ClassSchema> classInfoList = new ArrayList<ClassSchema>();

	/** 通过解析获得的所有接口信息 */
	private List<InterfaceSchema> interfaceInfoList = new ArrayList<InterfaceSchema>();

	/**
	 * parse方法是用来解析输入源码的（由handle方法调用），将输入源码的相关信息记录在classInfoList和interfaceInfoList中
	 * 
	 * 对输入文件的要求：输入文件中只含有一个类或者是一个接口；属性定义位于所有函数定义之上；数据类型声明中不能含有空格；接口不存在继承关系；不支持静态属性；不支持抽象类
	 * 
	 * @param inputFile 输入文件（非文件夹），即待解析的输入源码
	 * @param encode 输入文件编码格式
	 */
	private void parse(File inputFile, String encode) {
		BufferedReader br = null;
		try {
			//实例化读对象
			br = new BufferedReader(new InputStreamReader(new FileInputStream(inputFile), encode));
			//存储所有源码信息（相比String有性能优势）
			StringBuilder sb = new StringBuilder();
			String inputLine = null;
			while((inputLine = br.readLine()) != null) {
				sb.append(inputLine + "\n");
			}
			//sourceCode中为该文件的所有源码信息
			String sourceCode = sb.toString();
			//分别对源码进行类信息结构匹配和接口信息结构匹配
			Matcher classMatcher = classPattern.matcher(sourceCode);
			Matcher interfaceMatcher = interfacePattern.matcher(sourceCode);

			//如果类信息结构匹配成功（说明该输入文件中是一个类）
			if(classMatcher.find()) {
				//获取类定义信息
				String classInfo = classMatcher.group();
				//将源码中的类定义信息去除掉
				sourceCode = sourceCode.substring(sourceCode.indexOf(classInfo) + classInfo.length());
				//在剩下的源码中匹配方法定义信息
				Matcher functionMatcher = functionPattern.matcher(sourceCode);
				//如果匹配到了方法定义信息，再将剩下源码中方法定义信息全部去除掉（因为在匹配属性信息时，很可能将方法中的局部变量误匹配进去，所以这里先匹配方法定义信息，然后将其去除掉）
				if(functionMatcher.find()) {
					sourceCode = sourceCode.substring(0, sourceCode.indexOf(functionMatcher.group()));
				}
				//刚才上面调用了functionMatcher.find()，需要将functionMatcher重置
				functionMatcher.reset();
				//匹配类的属性信息
				Matcher attributeMatcher = attributePattern.matcher(sourceCode);

				ClassSchema classSchema = new ClassSchema();
				classInfo = classInfo.substring(0, classInfo.length() - 1).trim();
				String[] classInfoArr = classInfo.split("[ \t,]+");
				//获取访问类的权限信息和类名
				if(classInfoArr[0].trim().equals("private")) {
					classSchema.setAccessAuthority((byte)1);
					classSchema.setClassName(classInfoArr[2].trim());//获取类名称
					classInfoArr = Arrays.copyOfRange(classInfoArr, 3, classInfoArr.length);
				} else if(classInfoArr[0].trim().equals("protected")) {
					classSchema.setAccessAuthority((byte)3);
					classSchema.setClassName(classInfoArr[2].trim());
					classInfoArr = Arrays.copyOfRange(classInfoArr, 3, classInfoArr.length);
				} else if(classInfoArr[0].trim().equals("public")) {
					classSchema.setAccessAuthority((byte)4);
					classSchema.setClassName(classInfoArr[2].trim());
					classInfoArr = Arrays.copyOfRange(classInfoArr, 3, classInfoArr.length);
				} else {
					//类访问权限信息为default
					classSchema.setAccessAuthority((byte)2);
					classSchema.setClassName(classInfoArr[1].trim());
					classInfoArr = Arrays.copyOfRange(classInfoArr, 2, classInfoArr.length);
				}

				//获取类的取继承信息
				if(classInfoArr.length > 0 && classInfoArr[0].trim().equals("extends")) {
					List<String> extendsList = new ArrayList<String>();
					int i = 1;
					for(; i < classInfoArr.length && !classInfoArr[i].equals("implements"); i++) {
						extendsList.add(classInfoArr[i].trim());
					}
					classInfoArr = Arrays.copyOfRange(classInfoArr, i, classInfoArr.length);
					classSchema.setExtendsList(extendsList);
				} else {
					//该类没有继承信息
					classSchema.setExtendsList(Collections.<String>emptyList());
				}

				//获取类的实现信息
				if(classInfoArr.length > 0 && classInfoArr[0].trim().equals("implements")) {
					List<String> implementsList = new ArrayList<String>();
					int i = 1;
					for(; i < classInfoArr.length; i++) {
						implementsList.add(classInfoArr[i].trim());
					}
					classInfoArr = Arrays.copyOfRange(classInfoArr, i, classInfoArr.length);
					classSchema.setImplementsList(implementsList);
				} else {
					//该类没有实现信息
					classSchema.setImplementsList(Collections.<String>emptyList());
				}

				//获取类的属性信息
				List<AttributeSchema> attributeList = new ArrayList<AttributeSchema>();
				while(attributeMatcher.find()) {
					String attributeInfo = attributeMatcher.group().trim();
					attributeInfo = attributeInfo.substring(0, attributeInfo.length() - 1).trim();
					String[] attributeInfoArr = attributeInfo.split("[ \t]+");
					AttributeSchema attributeSchema = new AttributeSchema();
					//判断属性的访问权限
					if(attributeInfoArr[0].equals("private")) {
						attributeSchema.setAccessAuthority((byte)1);
						attributeSchema.setDataType(attributeInfoArr[1].trim());//获取属性数据类型
						attributeSchema.setAttributeName(attributeInfoArr[2].trim());//获取属性名称
					} else if(attributeInfoArr[0].equals("protected")) {
						attributeSchema.setAccessAuthority((byte)3);
						attributeSchema.setDataType(attributeInfoArr[1].trim());
						attributeSchema.setAttributeName(attributeInfoArr[2].trim());
					} else if(attributeInfoArr[0].equals("public")) {
						attributeSchema.setAccessAuthority((byte)4);
						attributeSchema.setDataType(attributeInfoArr[1].trim());
						attributeSchema.setAttributeName(attributeInfoArr[2].trim());
					} else {
						attributeSchema.setAccessAuthority((byte)2);
						attributeSchema.setDataType(attributeInfoArr[0].trim());
						attributeSchema.setAttributeName(attributeInfoArr[1].trim());
					}
					attributeList.add(attributeSchema);
				}
				classSchema.setAttributeList(attributeList);

				//获取类的方法信息
				List<FunctionSchema> functionList = new ArrayList<FunctionSchema>();
				while(functionMatcher.find()) {
					//以防发生误识别（new一个对象的形式和方法定义很类似）
					if(!functionMatcher.group().trim().contains("new")) {
						FunctionSchema FunctionSchema = new FunctionSchema();
						String functionInfo = functionMatcher.group().trim();
						//后面的2表示只切割一次，因为方法定义信息很复杂，这里采用一步步切割的方法
						String[] functionInfoArr = functionInfo.split("[ \t]+", 2);
						boolean flag = true;
						//判断方法的访问权限
						if(functionInfoArr[0].equals("private")) {
							FunctionSchema.setAccessAuthority((byte)1);
						} else if(functionInfoArr[0].equals("protected")) {
							FunctionSchema.setAccessAuthority((byte)3);
						} else if(functionInfoArr[0].equals("public")) {
							FunctionSchema.setAccessAuthority((byte)4);
						} else {
							FunctionSchema.setAccessAuthority((byte)2);
							flag = false;
						}
						//这里需要注意构造方法没有返回数据类型
						if(flag && !functionInfoArr[1].trim().contains(classSchema.getClassName())) {
							functionInfoArr = functionInfoArr[1].trim().split("[ \t]+", 2);
							if(functionInfoArr[0].trim().equals("static")) {
								FunctionSchema.setStaticFlag(true);
								functionInfoArr = functionInfoArr[1].trim().split("[ \t]+", 2);
							}
							FunctionSchema.setReturnType(functionInfoArr[0].trim());
						} else if(!functionInfoArr[1].trim().contains(classSchema.getClassName())){
							FunctionSchema.setReturnType(functionInfoArr[0].trim());
						}
						//获取方法名称
						functionInfoArr = functionInfoArr[1].trim().split("\\(", 2);
						FunctionSchema.setFunctionName(functionInfoArr[0].trim());
						//获取方法的传入参数信息
						functionInfoArr = functionInfoArr[1].trim().split("\\)", 2)[0].trim().split(",");
						if(functionInfoArr.length > 0 && !Arrays.toString(functionInfoArr).matches("\\[[ \t]*\\]")) {
							List<Parameter> parameterList = new ArrayList<Parameter>();
							for(int i = 0; i < functionInfoArr.length; i++) {
								String[] tmp = functionInfoArr[i].split("[ \t]+");
								Parameter parameter = new Parameter(tmp[0].trim(), tmp[1].trim());
								parameterList.add(parameter);
							}
							FunctionSchema.setParameterList(parameterList);
						} else {
							FunctionSchema.setParameterList(Collections.<Parameter>emptyList());
						}
						functionList.add(FunctionSchema);
					}
				}
				classSchema.setFunctionList(functionList);
				classInfoList.add(classSchema);
			}
			//如果接口信息结构匹配成功（说明该输入文件中是一个接口）
			else {
				interfaceMatcher.find();
				String interfaceInfo = interfaceMatcher.group();
				//在源码中去除接口定义信息部分
				sourceCode = sourceCode.substring(sourceCode.indexOf(interfaceInfo) + interfaceInfo.length());
				Matcher functionMatcher = functionPattern.matcher(sourceCode);

				//获取接口的访问权限信息和接口名称
				interfaceInfo = interfaceInfo.substring(0, interfaceInfo.length() - 1).trim();
				String[] interfaceInfoArr = interfaceInfo.split("[ \t]+");
				InterfaceSchema interfaceSchema = new InterfaceSchema();
				if(interfaceInfoArr[0].trim().equals("private")) {
					interfaceSchema.setAccessAuthority((byte)1);
					interfaceSchema.setInterfaceName(interfaceInfoArr[2].trim());
				} else if(interfaceInfoArr[0].trim().equals("protected")) {
					interfaceSchema.setAccessAuthority((byte)3);
					interfaceSchema.setInterfaceName(interfaceInfoArr[2].trim());
				} else if(interfaceInfoArr[0].trim().equals("public")) {
					interfaceSchema.setAccessAuthority((byte)4);
					interfaceSchema.setInterfaceName(interfaceInfoArr[2].trim());
				} else {
					interfaceSchema.setAccessAuthority((byte)2);
					interfaceSchema.setInterfaceName(interfaceInfoArr[1].trim());
				}

				//获取接口的方法信息（基本与获取类的方法信息相同）
				List<FunctionSchema> functionList = new ArrayList<FunctionSchema>();
				while(functionMatcher.find()) {
					if(!functionMatcher.group().trim().contains("new")) {
						FunctionSchema FunctionSchema = new FunctionSchema();
						String functionInfo = functionMatcher.group().trim();
						String[] functionInfoArr = functionInfo.split("[ \t]+", 2);
						boolean flag = true;
						if(functionInfoArr[0].equals("private")) {
							FunctionSchema.setAccessAuthority((byte)1);
						} else if(functionInfoArr[0].equals("protected")) {
							FunctionSchema.setAccessAuthority((byte)3);
						} else if(functionInfoArr[0].equals("public")) {
							FunctionSchema.setAccessAuthority((byte)4);
						} else {
							FunctionSchema.setAccessAuthority((byte)2);
							flag = false;
						}
						//注意抽象方法的处理
						if(functionInfoArr[1].trim().contains("abstract")) {
							functionInfoArr[1] = functionInfoArr[1].trim().split("[ \t]+", 2)[1];
						}
						//构造方法没有返回数据类型
						if(flag && !functionInfoArr[1].trim().contains(interfaceSchema.getInterfaceName())) {
							functionInfoArr = functionInfoArr[1].trim().split("[ \t]+", 2);
							if(functionInfoArr[0].trim().equals("static")) {
								FunctionSchema.setStaticFlag(true);
								functionInfoArr = functionInfoArr[1].trim().split("[ \t]+", 2);
							}
							FunctionSchema.setReturnType(functionInfoArr[0].trim());
						} else if(!functionInfoArr[1].trim().contains(interfaceSchema.getInterfaceName())){
							FunctionSchema.setReturnType(functionInfoArr[0].trim());
						}
						//获取方法名称
						functionInfoArr = functionInfoArr[1].trim().split("\\(", 2);
						FunctionSchema.setFunctionName(functionInfoArr[0].trim());
						//获取方法的传入参数信息
						functionInfoArr = functionInfoArr[1].trim().split("\\)", 2)[0].trim().split(",");
						if(functionInfoArr.length > 0 && !Arrays.toString(functionInfoArr).matches("\\[[ \t]*\\]")) {
							List<Parameter> parameterList = new ArrayList<Parameter>();
							for(int i = 0; i < functionInfoArr.length; i++) {
								String[] tmp = functionInfoArr[i].split("[ \t]+");
								Parameter parameter = new Parameter(tmp[0].trim(), tmp[1].trim());
								parameterList.add(parameter);
							}
							FunctionSchema.setParameterList(parameterList);
						} else {
							FunctionSchema.setParameterList(Collections.<Parameter>emptyList());
						}
						functionList.add(FunctionSchema);
					}
				}
				interfaceSchema.setFunctionList(functionList);
				interfaceInfoList.add(interfaceSchema);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if(br != null)	br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * handle方法是提供给外界调用的方法
	 * 该方法会解析输入文件夹中的所有.java文件
	 * 
	 * @param inputFolder 输入文件夹，该文件夹中包含着你需要解析的所有java文件，可以含有其他形式文件，该方法会自动进行过滤
	 * @param encode 解析输入文件夹中文件使用的字符编码形式
	 */
	public void handle(File inputFolder, String encode) {
		//文件过滤器
		FileFilter filter = new FileFilter() {
			//实现接口FileFilter中的accept方法：仅接受文件夹（可实现递归遍历文件夹中的文件）和.java文件
			public boolean accept(File file) {
				if(file.isDirectory()) {
					return true;
				} else {
					if(file.getName().endsWith(".java")) {
						return true;
					} else {
						return false;
					}
				}
			}
		};
		List<File> fileList = new ArrayList<File>();
		//获取inputFolder中的所有.java文件
		getNeedFile(inputFolder, filter, fileList);
		//对每个.java文件进行解析
		for(File file : fileList) {
			parse(file, encode);
		}
	}

	/**
	 * getJavaFile会递归遍历输入文件夹中的所有文件，然后记录该文件夹中所有满足文件过滤器的文件
	 * 
	 * @param inputFolder 输入文件夹
	 * @param filter 文件过滤器
	 * @fileList 记录满足文件过滤器的文件
	 */
	private void getNeedFile(File inputFolder, FileFilter filter, List<File> fileList) {
		File[] files = inputFolder.listFiles(filter);
		for(File file : files) {
			if(file.isDirectory()) {
				getNeedFile(file, filter, fileList);
			} else {
				fileList.add(file);
			}
		}
	}

	/** classInfoList的get方法 */
	public List<ClassSchema> getClassInfoList() {
		return classInfoList;
	}

	/** interfaceInfoList的get方法 */
	public List<InterfaceSchema> getInterfaceInfoList() {
		return interfaceInfoList;
	}
}
