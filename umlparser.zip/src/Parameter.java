

/**
 * Parameter 方法传入参数信息结构
 * 用来存储方法传入参数的信息
 *
 */
public class Parameter {
	
	/** 参数数据类型 */
	private String parameterType = null;
	
	/** 参数名称 */
	private String parameterName = null;
	
	/** 构造方法 */
	public Parameter(String parameterType, String parameterName) {
		super();
		this.parameterType = parameterType;
		this.parameterName = parameterName;
	}
	
	/** 下面为所有属性的get方法 */
	public String getParameterType() {
		return parameterType;
	}

	public String getParameterName() {
		return parameterName;
	}
}
