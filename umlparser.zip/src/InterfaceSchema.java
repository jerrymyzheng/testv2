

import java.util.List;

/**
 * InterfaceSchema 接口信息结构
 * 用来存储接口的所有信息
 *
 */
public class InterfaceSchema {

	/**
	 * 接口的访问权限
	 * 1:private; 2:default; 3:protected; 4:public
	 * */
	private byte accessAuthority;

	/** 接口名称 */
	private String interfaceName = null;

	/** 该接口的所有方法 */
	private List<FunctionSchema> functionList = null;

	/** 构造方法 */
	public InterfaceSchema() {
		super();
	}

	/** 下面为所有属性的set和get方法 */
	public byte getAccessAuthority() {
		return accessAuthority;
	}

	public void setAccessAuthority(byte accessAuthority) {
		this.accessAuthority = accessAuthority;
	}

	public String getInterfaceName() {
		return interfaceName;
	}

	public void setInterfaceName(String interfaceName) {
		this.interfaceName = interfaceName;
	}

	public List<FunctionSchema> getFunctionList() {
		return functionList;
	}

	public void setFunctionList(List<FunctionSchema> functionList) {
		this.functionList = functionList;
	}
}
