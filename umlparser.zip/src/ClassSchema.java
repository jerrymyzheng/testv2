

import java.util.List;

/**
 * ClassSchema 类信息结构
 * 用来存储类的所有信息
 *
 */
public class ClassSchema {

	/**
	 * 类的访问权限
	 * 1:private; 2:default; 3:protected; 4:public
	 * */
	private byte accessAuthority;

	/** 类名称 */
	private String className = null;

	/** 该类继承的所有类，其实这里最多只有一个，因为Java只支持单继承 */
	private List<String> extendsList = null;

	/** 该类实现的所有接口 */
	private List<String> implementsList = null;

	/** 该类的所有属性 */
	private List<AttributeSchema> attributeList = null;

	/** 该类的所有方法 */
	private List<FunctionSchema> functionList = null;

	/** 构造方法 */
	public ClassSchema() {
		super();
	}

	/** 下面为所有属性的set和get方法 */
	public byte getAccessAuthority() {
		return accessAuthority;
	}

	public void setAccessAuthority(byte accessAuthority) {
		this.accessAuthority = accessAuthority;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public List<String> getExtendsList() {
		return extendsList;
	}

	public void setExtendsList(List<String> extendsList) {
		this.extendsList = extendsList;
	}

	public List<String> getImplementsList() {
		return implementsList;
	}

	public void setImplementsList(List<String> implementsList) {
		this.implementsList = implementsList;
	}

	public List<AttributeSchema> getAttributeList() {
		return attributeList;
	}

	public void setAttributeList(List<AttributeSchema> attributeList) {
		this.attributeList = attributeList;
	}

	public List<FunctionSchema> getFunctionList() {
		return functionList;
	}

	public void setFunctionList(List<FunctionSchema> functionList) {
		this.functionList = functionList;
	}
}
